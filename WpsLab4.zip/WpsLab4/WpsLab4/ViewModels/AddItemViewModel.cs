﻿using System.Collections.ObjectModel;
using System.Linq;
using WpsLab4.Models;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace WpsLab4.ViewModels
{
    public class AddItemViewModel : BaseViewModel
    {
        private ObservableCollection<Basket> _baskets;
        private ObservableCollection<Product> _products;
        private Basket _selectedBasket;
        private Product _selectedProduct;
        private int _quantity;

        public ObservableCollection<Basket> Baskets
        {
            get => _baskets;
            set { _baskets = value; OnPropertyChanged(); }
        }

        public ObservableCollection<Product> Products
        {
            get => _products;
            set { _products = value; OnPropertyChanged(); }
        }

        public Basket SelectedBasket
        {
            get => _selectedBasket;
            set { _selectedBasket = value; OnPropertyChanged(); }
        }

        public Product SelectedProduct
        {
            get => _selectedProduct;
            set { _selectedProduct = value; OnPropertyChanged(); }
        }

        public int Quantity
        {
            get => _quantity;
            set { _quantity = value; OnPropertyChanged(); }
        }

        public RelayCommand SaveCommand { get; }

        public AddItemViewModel()
        {
            LoadBaskets();
            LoadProducts();
            SaveCommand = new RelayCommand(SaveItem);
        }

        private void LoadBaskets()
        {
            using (var context = new OmsContext())
            {
                Baskets = new ObservableCollection<Basket>(context.Baskets.Include(b => b.IdShopperNavigation).ToList());
            }
        }

        private void LoadProducts()
        {
            using (var context = new OmsContext())
            {
                Products = new ObservableCollection<Product>(context.Products.ToList());
            }
        }

        private void SaveItem()
        {
            using (var context = new OmsContext())
            {
                if (SelectedBasket != null && SelectedProduct != null)
                {
                    // Find the maximum IdBasketItem
                    int maxId = context.BasketItems.Any() ? context.BasketItems.Max(bi => bi.IdBasketItem) : 0;

                    var newItem = new BasketItem
                    {
                        IdBasketItem = maxId + 1,
                        IdBasket = SelectedBasket.IdBasket,
                        IdProduct = SelectedProduct.IdProduct,
                        Quantity = (byte)Quantity
                    };

                    context.BasketItems.Add(newItem);
                    context.SaveChanges();

                    // Close the AddItemWindow after saving
                    foreach (Window window in Application.Current.Windows)
                    {
                        if (window is AddItemWindow)
                        {
                            window.Close();
                            break;
                        }
                    }
                }
            }
        }
    }
}