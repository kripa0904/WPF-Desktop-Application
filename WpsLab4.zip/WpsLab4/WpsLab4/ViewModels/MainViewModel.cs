﻿using System.Collections.ObjectModel;
using System.Linq;
using WpsLab4.Models;
using WpsLab4.ViewModels;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace WpsLab4.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        private ObservableCollection<Basket> _baskets;
        private ObservableCollection<BasketItem> _basketItems;

        public ObservableCollection<Basket> Baskets
        {
            get => _baskets;
            set { _baskets = value; OnPropertyChanged(); }
        }

        public ObservableCollection<BasketItem> BasketItems
        {
            get => _basketItems;
            set { _basketItems = value; OnPropertyChanged(); }
        }

        private Basket _selectedBasket;

        public Basket SelectedBasket
        {
            get => _selectedBasket;
            set { _selectedBasket = value; LoadBasketItems(); OnPropertyChanged(); }
        }

        public RelayCommand OpenAddItemCommand { get; }

        public MainViewModel()
        {
            LoadBaskets();
            OpenAddItemCommand = new RelayCommand(OpenAddItem);
        }

        private void LoadBaskets()
        {
            using (var context = new OmsContext())
            {
                Baskets = new ObservableCollection<Basket>(context.Baskets.Include(b => b.IdShopperNavigation).ToList());
            }
        }

        private void LoadBasketItems()
        {
            if (SelectedBasket != null)
            {
                using (var context = new OmsContext())
                {
                    BasketItems = new ObservableCollection<BasketItem>(
                        context.BasketItems.Where(bi => bi.IdBasket == SelectedBasket.IdBasket)
                        .Include(bi => bi.IdProductNavigation).ToList());
                }
            }
            else
                BasketItems = new ObservableCollection<BasketItem>();
        }

        private void OpenAddItem()
        {
            var addItemWindow = new AddItemWindow();
            addItemWindow.DataContext = new AddItemViewModel();  // Set DataContext here
            addItemWindow.ShowDialog();

            // Refresh basket items after adding an item
            LoadBasketItems();
        }

    }
}