﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpsLab4.ViewModels;

namespace WpsLab4
{
    public partial class AddItemWindow : Window
    {
        public AddItemWindow()
        {
            InitializeComponent();
            DataContext = new AddItemViewModel();
        }

        private void btnCancelItemAddItemWindow_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
